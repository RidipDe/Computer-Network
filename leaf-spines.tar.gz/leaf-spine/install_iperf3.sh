#!/bin/bash
sudo dpkg -i  iperf3_3.1.3-1_amd64.deb libiperf0_3.1.3-1_amd64.deb
sudo apt-get install -f
